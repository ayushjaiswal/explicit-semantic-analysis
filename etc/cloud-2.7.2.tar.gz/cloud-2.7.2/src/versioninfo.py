# This file defines versioning information
release_version="2.7.2"
git_revision="ba95a2ff456355e4a4b1c194b64a7d243529cb4b"
